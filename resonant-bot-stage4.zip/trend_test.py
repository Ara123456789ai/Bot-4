#!/usr/bin/env python3
"""
Technical-filter test: Saturn-only sells with a price-action trend filter (stage 3).

Astro   : Saturn aspect to the Ascendant at 45, 120, 135 or 150 degrees (3 degree orb) and the Saturn actors strip amber
          (2+ actors lit). No Sentiment Index condition and no Moon gate unless you ask for them (--gate / --s-red below).
Entry   : a sell at the close of the first bar (1-minute, then 5-minute) inside that astro window where
            1. the close is below the 12-bar EMA of closes,
            2. the bar is a bear trend bar: it closes below its open by more than 10 points (--bar-size), and
            3. it closes below the previous bar's low (--prev close = below the previous bar's close instead).
          One trade per aspect window; windows whose conditions hold for under 5 minutes are skipped (as before).
Exit    : SL 300 points, TP 500 points (no 750 tint extension), or the last allowed Saturn aspect leaves the 3 degree orb.
Rows    : the spec on 1-minute and 5-minute bars, each aspect angle on its own, the same rule plus S below -0.15, plus the Moon gate,
          and an "astro only" reference (first minute, same exits) to show what the technical filter adds.
Run     : python3 trend_test.py --prices download/brentcmdusd-m1-bid-2024-01-01-2026-11-10.csv > trend_report.txt
"""
import argparse, bisect, csv, os, re, statistics, sys, time
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import backtest as B
import entry_tests as T

MIN, DAY, SELL = B.MIN, B.DAY, T.SELL
ALLOWED = (45, 120, 135, 150)
IDX = [SELL.index(x) for x in ALLOWED]


def ema_series(c, ok, every, period):
    """EMA of closes. every=1: each minute; every=5: 5-minute bars ending at minute k%5==4. Value stored at the bar's last minute."""
    al = 2.0 / (period + 1)
    out = [None] * len(c)
    e = None
    for k in range(len(c)):
        if every == 5 and (k % 5 != 4 or k < 4 or not (ok[k] and ok[k - 4])):
            continue
        if every == 1 and not ok[k]:
            continue
        e = c[k] if e is None else e + al * (c[k] - e)
        out[k] = e
    return out


class Ctx:
    pass


def trend_ok(k, every, X):
    """Does the bar ending at minute k satisfy the technical conditions? Returns True/False."""
    o, h, l, c, p = X.o, X.h, X.l, X.c, X.p
    pt = p["point"]
    if every == 1:
        if k < 1 or not (X.ok[k] and X.ok[k - 1]):
            return False
        bo, bc, bh, bl = o[k], c[k], h[k], l[k]
        pl, pc = l[k - 1], c[k - 1]
        e = X.ema1[k]
    else:
        if k % 5 != 4 or k < 9 or X.ema5[k] is None or X.ema5[k - 5] is None:
            return False
        bo, bc = o[k - 4], c[k]
        bh, bl = max(h[k - 4:k + 1]), min(l[k - 4:k + 1])
        pl, pc = min(l[k - 9:k - 4]), c[k - 5]
        e = X.ema5[k]
    if e is None or not (bc < e):
        return False
    size = (bo - bc) if X.measure == "body" else (bh - bl)
    if not (bc < bo and size > X.bar_pts * pt):
        return False
    return bc < (pl if X.prev == "low" else pc)


def run(mode, act_b, el_b, X):
    """mode: 'astro' = first minute, 'm1' = 1-minute trend bar, 'm5' = 5-minute trend bar. Returns (k, exit_idx, reason, pnl, angle_idx)."""
    n, p = len(X.o), X.p
    spans = [(m.start(), m.end()) for m in re.finditer(rb"\x01+", el_b) if m.end() - m.start() >= p["min_run"]]
    eps = [m.start() for m in re.finditer(rb"\x01+", act_b)]
    zero = bytes(n)
    out, last_ep, free = [], -1, 0
    for a, b in spans:
        for k in range(max(a, free), b):
            if not X.can[k] or k < 10 or k >= n - 3:
                continue
            ep = bisect.bisect_right(eps, k) - 1
            if ep == last_ep:
                break
            if mode == "astro":
                if X.ok[k] != 1:
                    continue
                j0, e0 = k, X.o[k]
            else:
                if not trend_ok(k, 1 if mode == "m1" else 5, X):
                    continue
                j0, e0 = k + 1, X.c[k]
            jx, reason, pnl, _ = T.manage(j0, e0, False, act_b, X.o, X.h, X.l, X.c, zero, X.flat, p)
            out.append((k, jx, reason, pnl, X.sa[k]))
            last_ep, free = ep, jx + 1
            break
    return out


def masks(sa, samb, sred, mhard, angle_idx, s_red, moon):
    n = len(sa)
    I = lambda b: int.from_bytes(b, "big")
    tbl = bytes(1 if v in angle_idx else 0 for v in range(256))
    act = I(sa.translate(tbl))
    el = act & I(samb)
    if s_red:
        el &= I(sred)
    if moon:
        el &= I(mhard)
    return act.to_bytes(n, "big"), el.to_bytes(n, "big")


def describe(tr, lo, p):
    s = T.stats(tr, lo, p)
    pts = [t[3] / p["point"] for t in tr]
    w = [x for x in pts if x > 0]
    ls = [x for x in pts if x < 0]
    s["avg_win"] = statistics.mean(w) if w else 0.0
    s["avg_loss"] = statistics.mean(ls) if ls else 0.0
    s["be"] = 100 * abs(s["avg_loss"]) / (s["avg_win"] + abs(s["avg_loss"])) if w and ls else float("nan")
    s["mix"] = {r: sum(1 for t in tr if t[2] == r) for r in ("SL", "TP", "ASPECT", "FLAT", "END")}
    return s


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--prices", required=True)
    ap.add_argument("--cache", default="astro2_cache.pkl")
    ap.add_argument("--start"); ap.add_argument("--end")
    ap.add_argument("--spread", type=float, default=0.021)
    ap.add_argument("--point", type=float, default=0.001)
    ap.add_argument("--sl", type=float, default=300); ap.add_argument("--tp", type=float, default=500)
    ap.add_argument("--ema", type=int, default=12)
    ap.add_argument("--bar-size", type=float, default=10, help="minimum size of the bear bar in points")
    ap.add_argument("--measure", choices=["body", "range"], default="body", help="bar size = open minus close (body) or high minus low (range)")
    ap.add_argument("--prev", choices=["low", "close"], default="low", help="the bar must close below the previous bar's low (or close)")
    ap.add_argument("--min-run", type=int, default=5)
    ap.add_argument("--window-start", default="04:00")
    ap.add_argument("--close-hour", type=int, default=22)
    ap.add_argument("--last-entry-margin", type=int, default=30)
    ap.add_argument("--flatten-margin", type=int, default=5)
    ap.add_argument("--server-offset", type=float, default=0.0)
    ap.add_argument("--price-offset", type=float, default=0.0)
    ap.add_argument("--null", type=int, default=20)
    ap.add_argument("--out", default="trend_trades.csv")
    a = ap.parse_args()

    wh, wm = (int(x) for x in a.window_start.split(":"))
    p = dict(spread=a.spread, point=a.point, sl=a.sl, tp=a.tp, tp_tint=a.tp, min_run=a.min_run,
             window_start=(wh, wm), close_hour=a.close_hour, last_entry_margin=a.last_entry_margin,
             flatten_margin=a.flatten_margin, server_offset=a.server_offset)
    pr = B.load_prices(a.prices, a.price_offset)
    ts = sorted(pr)
    lo = max(ts[0], int(datetime.fromisoformat(a.start).replace(tzinfo=timezone.utc).timestamp() * 1000)) if a.start else ts[0]
    hi = min(ts[-1], int(datetime.fromisoformat(a.end).replace(tzinfo=timezone.utc).timestamp() * 1000)) if a.end else ts[-1]
    lo, hi = lo // DAY * DAY, (hi // DAY + 1) * DAY
    n = (hi - lo) // MIN
    print(f"prices: {len(pr)} minute bars; testing {n} minutes", file=sys.stderr)
    A = T.build_astro(lo, hi, a.cache)
    o, h, l, c, ok = B.align_prices(pr, lo, n)
    can, flat = B.make_windows(lo, n, p)

    X = Ctx()
    X.o, X.h, X.l, X.c, X.ok, X.can, X.flat, X.p = o, h, l, c, ok, can, flat, p
    X.sa, X.measure, X.bar_pts, X.prev = A["sa"], a.measure, a.bar_size, a.prev
    X.ema1 = ema_series(c, ok, 1, a.ema)
    X.ema5 = ema_series(c, ok, 5, a.ema)

    modes = [("astro", "astro only, first minute (reference)"), ("m1", "1-minute trend bar"), ("m5", "5-minute trend bar")]
    rows, res = [], {}
    t0 = time.time()

    def go(mode, label, angles=IDX, s_red=False, moon=False, arrays=None):
        sa, samb, sred, mhard = arrays or (A["sa"], A["samb"], A["sred"], A["mhard"])
        act, el = masks(sa, samb, sred, mhard, angles, s_red, moon)
        X.sa = sa
        tr = run(mode, act, el, X)
        s = describe(tr, lo, p)
        rows.append((mode, label, s["n"], round(s["win"], 1), round(s["mean"], 1), round(s["t"], 2)))
        return s, tr

    pts_note = "body" if a.measure == "body" else "range"
    print(f"Saturn aspects {ALLOWED}, actors strip amber; EMA {a.ema}; bear bar {pts_note} > {a.bar_size:g} points; close below previous bar's {a.prev}; "
          f"SL {a.sl:g}, TP {a.tp:g}, exit when the aspect leaves the 3 degree orb; spread {a.spread}")
    print("\n=== 1. THE RULE AS SPECIFIED (no Sentiment Index, no Moon gate) ===")
    print(f"{'entry':40s}    n    mean   (t)    win%  avg win  avg loss  break-even win%   2024-25   2026    exits SL/TP/aspect")
    all_tr = {}
    for mode, name in modes:
        s, tr = go(mode, "spec")
        res[(mode, "spec")] = s
        all_tr[mode] = tr
        ins = "   -  " if s["m_ins"] is None else f"{s['m_ins']:+6.1f}"
        out = "   -  " if s["m_out"] is None else f"{s['m_out']:+6.1f}"
        mx = s["mix"]
        print(f"{name:40s} {T.fmt(s)}  {s['win']:5.1f}  {s['avg_win']:+7.1f}  {s['avg_loss']:+8.1f}      {s['be']:5.1f}       {ins} {out}    "
              f"{mx['SL']}/{mx['TP']}/{mx['ASPECT']}")

    print("\n=== 2. EACH ASPECT ANGLE ON ITS OWN: n, mean points, (t of the gross edge) ===")
    print(f"{'angle':>6s}   " + "   ".join(f"{name[:26]:^22s}" for _, name in modes))
    for ang, i in zip(ALLOWED, IDX):
        line = f"{ang:>5d}° "
        for mode, name in modes:
            s, _ = go(mode, f"angle {ang}", [i])
            res[(mode, f"angle {ang}")] = s
            line += "   " + T.fmt(s).rjust(22)
        print(line)

    print("\n=== 3. EXTRA CONDITIONS ADDED TO THE SPEC: n, mean points, (t of the gross edge) ===")
    print(f"{'condition':30s}   " + "   ".join(f"{name[:26]:^22s}" for _, name in modes))
    for label, kw in (("plus Sentiment Index S < -0.15", dict(s_red=True)), ("plus Moon hard-aspect gate", dict(moon=True)),
                      ("plus both", dict(s_red=True, moon=True))):
        line = f"{label:30s}"
        for mode, name in modes:
            s, _ = go(mode, label, **kw)
            res[(mode, label)] = s
            line += "   " + T.fmt(s).rjust(22)
        print(line)

    m = len(rows)
    from statistics import NormalDist
    z = NormalDist().inv_cdf(1 - 0.025 / max(1, m))
    print(f"\n=== 4. HOW MUCH TO TRUST ANY SINGLE ROW ===")
    print(f"{m} variants were tested. A row only counts as a real edge if its gross t is above {z:.1f}, AND its net mean is above zero, "
          f"AND it is positive in both 2024-25 and 2026, AND n >= 100.")
    good = []
    for (mode, label), s in res.items():
        if s["n"] >= 100 and s["t"] >= z and s["mean"] > 0 and (s["m_ins"] or 0) > 0 and (s["m_out"] or 0) > 0:
            good.append((mode, label, s))
    print("rows that pass:", "none" if not good else "")
    for mode, label, s in good:
        print(f"    {mode} {label}: n={s['n']} mean={s['mean']:+.1f} t={s['t']:+.2f}")
    top = sorted([(k, s) for k, s in res.items() if s["n"] >= 100], key=lambda x: -x[1]["mean"])[:6]
    print("best six by net mean (n >= 100):")
    for (mode, label), s in top:
        print(f"    {mode:5s} {label:32s} n={s['n']:5d} mean={s['mean']:+7.1f} t={s['t']:+5.2f}")
    print(f"variants with n >= 100 and a positive net mean: {sum(1 for s in res.values() if s['n'] >= 100 and s['mean'] > 0)} of {sum(1 for s in res.values() if s['n'] >= 100)}")

    if a.null > 0:
        print("\n=== 5. RANDOM-TIMING TEST for the three spec rows: astro pattern shifted by whole weeks ===")
        shifts = [s for w in range(1, a.null // 2 + 2) for s in (w, -w)][:a.null]
        for mode, name in modes:
            real = res[(mode, "spec")]["mean"]
            null = []
            for w in shifts:
                r = w * 7 * 1440
                sh = lambda b: (b[-r:] + b[:-r]) if r > 0 else (b[-r:] + b[:-r] if r < 0 else b)
                arrs = tuple(sh(A[k]) for k in ("sa", "samb", "sred", "mhard"))
                act, el = masks(arrs[0], arrs[1], arrs[2], arrs[3], IDX, False, False)
                X.sa = arrs[0]
                tr = run(mode, act, el, X)
                if tr:
                    null.append(statistics.mean(x[3] for x in tr) / p["point"])
            if null:
                print(f"{name:40s} real {real:+6.1f}; shifted runs mean {statistics.mean(null):+6.1f}, best {max(null):+6.1f}, "
                      f"worst {min(null):+6.1f}; real beats {100*sum(1 for x in null if x < real)/len(null):.0f}% of them")

    X.sa = A["sa"]
    with open(a.out, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["entry_mode", "entry_utc", "exit_utc", "reason", "points", "angle"])
        for mode, tr in all_tr.items():
            for k, jx, reason, pnl, ai in tr:
                tu = lambda i: datetime.fromtimestamp((lo + i * MIN) / 1000, tz=timezone.utc).strftime("%Y-%m-%d %H:%M")
                w.writerow([mode, tu(k), tu(jx), reason, round(pnl / p["point"], 1), SELL[ai] if ai < len(SELL) else ""])
    print(f"\ntrades of the three spec rows written to {a.out}; all rows tested: {m}   (took {time.time()-t0:.0f}s)")


if __name__ == "__main__":
    main()
