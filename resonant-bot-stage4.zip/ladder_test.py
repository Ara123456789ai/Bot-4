#!/usr/bin/env python3
"""
Four-level sell ladder (stage 4). All sells, whole-lot 10% sizing unchanged (so only points are tested here).

Level 1  Heliocentric Sun field falling AND the Mercury card falling. "Falling" = the red tint behind the Sun-only / Mercury-only
         Ascendant panes: this 5-minute bar's running total minus the previous bar's is below zero (the same rule as before, which
         matched your screenshots for the Sun pane).
Level 2  The transiting Moon has at least 2 hard aspects (conjunction, 45, 90, 135, 150, 180; 3 degree orb) among: transit Mars, Sun,
         Jupiter and natal Mars, Sun, Jupiter (six possible targets).
Level 3  Saturn or Pluto aspects the Ascendant at 45, 60, 90, 120, 135 or 150 (3 degree orb), that planet's actors strip is amber
         (2+ actors) with the Moon lit, AND that planet is "resonant": its natal point is aspected by the transiting Midheaven
         (any app angle, 3 degree orb). --res either = natal Pluto OR natal Saturn on the Midheaven is enough.
Level 4  On 1-minute bars: sell at the close of the first bar that closes below the 12-period EMA of lows.
         Stop loss 300 points above the sell price (ask side). When price has moved 300 points into profit the stop goes to breakeven
         (active from the next bar). From then on the stop trails the 12-period EMA of highs (it only ever moves down).
         No take profit. Flat before the close (and optional --exit-aspect: also exit when the Level 3 aspect ends).
One trade per Level 3 aspect window (--per-window), signals shorter than 5 minutes skipped, window from 04:00 London to 22:00 broker close.
"""
import argparse, bisect, csv, os, pickle, re, statistics, sys, time
from datetime import datetime, timezone
from multiprocessing import Pool

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import resonant_engine as E
import backtest as B
import entry_tests as T

MIN, DAY, SELL = B.MIN, B.DAY, T.SELL
ALLOWED = (45, 60, 90, 120, 135, 150)
IDX = [SELL.index(x) for x in ALLOWED]
FIELDS3 = ["mfall", "moon2", "mcp", "mcs"]


# ------------------------------------------------------------------ extra astro flags (Mercury tint, Moon count, Midheaven resonance)
def _chunk3(args):
    a, b = args
    cols = {k: bytearray() for k in FIELDS3}
    cur_tb, cur_fall = None, 0
    t = a
    while t < b:
        tb = t // E.BAR_MS * E.BAR_MS
        if tb != cur_tb:
            cur_tb = tb
            cur_fall = 1 if E.merc_trend(tb) < 0 else 0
        cols["mfall"].append(cur_fall)
        cols["moon2"].append(1 if E.moon_hard_count(E.planetary_positions(t)) >= 2 else 0)
        mc = E.midheaven(t)
        cols["mcp"].append(1 if E.mc_active(mc, "Pluto") else 0)
        cols["mcs"].append(1 if E.mc_active(mc, "Saturn") else 0)
        t += MIN
    return [bytes(cols[k]) for k in FIELDS3]


def build_astro3(start_ms, end_ms, cache):
    if cache and os.path.exists(cache):
        with open(cache, "rb") as f:
            d = pickle.load(f)
        if d.get("v") == 1 and d["start"] == start_ms and d["end"] == end_ms:
            print(f"stage 4 astro flags loaded from {cache}", file=sys.stderr)
            return d
    jobs = [(t, min(t + 2 * DAY, end_ms)) for t in range(start_ms, end_ms, 2 * DAY)]
    t0 = time.time()
    with Pool() as p:
        parts = p.map(_chunk3, jobs)
    d = {"v": 1, "start": start_ms, "end": end_ms}
    for i, k in enumerate(FIELDS3):
        d[k] = b"".join(pt[i] for pt in parts)
    print(f"stage 4 astro flags built in {time.time()-t0:.0f}s", file=sys.stderr)
    if cache:
        with open(cache, "wb") as f:
            pickle.dump(d, f)
    return d


# ------------------------------------------------------------------ indicators and one trade
def ema_carry(x, ok, period):
    """EMA over the bars with ok=1; the last value is carried over missing minutes (None until the first bar)."""
    al = 2.0 / (period + 1)
    out, e = [None] * len(x), None
    for k in range(len(x)):
        if ok[k]:
            e = x[k] if e is None else e + al * (x[k] - e)
        out[k] = e
    return out


def manage_trail(j0, e0, act, X, trail_from, exit_aspect):
    """Short trade. Stop orders trigger on the ask (bar high + spread). Returns (exit index, reason, pnl, hold bars)."""
    o, h, l, c, flat, p, eh = X.o, X.h, X.l, X.c, X.flat, X.p, X.emaH
    n = len(o)
    sp, pt = p["spread"], p["point"]
    sl0 = e0 + p["sl"] * pt
    stop, be_on, trail_on = sl0, False, trail_from == "entry"
    j = j0
    while True:
        if h[j] + sp >= stop:
            fill = max(stop, o[j] + sp)
            pnl = e0 - fill
            reason = "SL" if stop == sl0 else ("BE" if be_on and abs(stop - e0) < 1e-12 else "TRAIL")
            return j, reason, pnl
        if not be_on and l[j] + sp <= e0 - p["be"] * pt:
            be_on, trail_on = True, True
            stop = min(stop, e0)
        if trail_on and eh[j] is not None:
            stop = min(stop, eh[j])
        nx = j + 1
        if nx >= n:
            return j, "END", e0 - (c[j] + sp)
        if flat[nx]:
            return nx, "FLAT", e0 - (o[nx] + sp)
        if exit_aspect and not act[nx]:
            return nx, "ASPECT", e0 - (o[nx] + sp)
        j = nx


def run(act_b, el_b, X, trail_from="be", exit_aspect=False, per_window=1):
    n, p = len(X.o), X.p
    spans = [(m.start(), m.end()) for m in re.finditer(rb"\x01+", el_b) if m.end() - m.start() >= p["min_run"]]
    eps = [m.start() for m in re.finditer(rb"\x01+", act_b)]
    out, used, free = [], {}, 0
    for a, b in spans:
        for k in range(max(a, free), b):
            if not X.can[k] or k < 14 or k >= n - 3 or X.ok[k] != 1:
                continue
            ep = bisect.bisect_right(eps, k) - 1
            if used.get(ep, 0) >= per_window:
                break
            if X.emaL[k] is None or not (X.c[k] < X.emaL[k]):
                continue
            jx, reason, pnl = manage_trail(k + 1, X.c[k], act_b, X, trail_from, exit_aspect)
            out.append((k, jx, reason, pnl))
            used[ep] = used.get(ep, 0) + 1
            free = jx + 1
            break
    return out


# ------------------------------------------------------------------ masks (big integers: fast & | ^)
class M:
    def __init__(self, A, A3):
        self.n = n = len(A["sa"])
        I = lambda b: int.from_bytes(b, "big")
        self.I = I
        self.ones = I(b"\x01" * n)
        tbl = bytes(1 if v in IDX else 0 for v in range(256))
        self.pa, self.sa = I(A["pa"].translate(tbl)), I(A["sa"].translate(tbl))
        self.pamb, self.samb, self.mp, self.ms = I(A["pamb"]), I(A["samb"]), I(A["mp"]), I(A["ms"])
        self.fall, self.mfall, self.moon2 = I(A["fall"]), I(A3["mfall"]), I(A3["moon2"])
        self.mcp, self.mcs = I(A3["mcp"]), I(A3["mcs"])

    def build(self, l1=True, l2=True, res="own", kinds=("pluto", "saturn")):
        o = self.ones
        g = (self.fall & self.mfall if l1 else o) & (self.moon2 if l2 else o)
        rp = self.mcp if res == "own" else (self.mcp | self.mcs) if res == "either" else o
        rs = self.mcs if res == "own" else (self.mcp | self.mcs) if res == "either" else o
        act = 0
        el3 = 0
        if "pluto" in kinds:
            act |= self.pa
            el3 |= self.pa & self.pamb & self.mp & rp
        if "saturn" in kinds:
            act |= self.sa
            el3 |= self.sa & self.samb & self.ms & rs
        return act.to_bytes(self.n, "big"), (el3 & g).to_bytes(self.n, "big"), el3, g


def shifted(A, A3, r):
    sh = lambda b: (b[-r:] + b[:-r]) if r > 0 else (b[-r:] + b[:-r] if r < 0 else b)
    A2 = {k: (sh(v) if isinstance(v, (bytes, bytearray)) else v) for k, v in A.items()}
    B2 = {k: (sh(v) if isinstance(v, (bytes, bytearray)) else v) for k, v in A3.items()}
    return A2, B2


def describe(tr, lo, p):
    s = T.stats(tr, lo, p)
    pts = [t[3] / p["point"] for t in tr]
    w = [x for x in pts if x > 0]
    ls = [x for x in pts if x < 0]
    s["avg_win"] = statistics.mean(w) if w else 0.0
    s["avg_loss"] = statistics.mean(ls) if ls else 0.0
    s["hold"] = statistics.median(t[1] - t[0] for t in tr) if tr else 0
    s["mix"] = {r: sum(1 for t in tr if t[2] == r) for r in ("SL", "BE", "TRAIL", "FLAT", "ASPECT", "END")}
    return s


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--prices", required=True)
    ap.add_argument("--cache", default="astro2_cache.pkl", help="stage 2 astro flags (built if missing)")
    ap.add_argument("--cache3", default="astro3_cache.pkl", help="stage 4 astro flags (Mercury tint, Moon count, Midheaven)")
    ap.add_argument("--start"); ap.add_argument("--end")
    ap.add_argument("--spread", type=float, default=0.021)
    ap.add_argument("--point", type=float, default=0.001)
    ap.add_argument("--sl", type=float, default=300)
    ap.add_argument("--be", type=float, default=300, help="profit in points that moves the stop to breakeven")
    ap.add_argument("--ema", type=int, default=12)
    ap.add_argument("--res", choices=["own", "either", "off"], default="own",
                    help="own = the triggering planet's natal point is on the Midheaven; either = natal Pluto or Saturn; off")
    ap.add_argument("--per-window", type=int, default=1)
    ap.add_argument("--min-run", type=int, default=5)
    ap.add_argument("--window-start", default="04:00")
    ap.add_argument("--close-hour", type=int, default=22)
    ap.add_argument("--last-entry-margin", type=int, default=30)
    ap.add_argument("--flatten-margin", type=int, default=5)
    ap.add_argument("--server-offset", type=float, default=0.0)
    ap.add_argument("--price-offset", type=float, default=0.0)
    ap.add_argument("--null", type=int, default=20)
    ap.add_argument("--out", default="ladder_trades.csv")
    a = ap.parse_args()

    wh, wm = (int(x) for x in a.window_start.split(":"))
    p = dict(spread=a.spread, point=a.point, sl=a.sl, be=a.be, tp=0, tp_tint=0, min_run=a.min_run,
             window_start=(wh, wm), close_hour=a.close_hour, last_entry_margin=a.last_entry_margin,
             flatten_margin=a.flatten_margin, server_offset=a.server_offset)
    pr = B.load_prices(a.prices, a.price_offset)
    ts = sorted(pr)
    lo = max(ts[0], int(datetime.fromisoformat(a.start).replace(tzinfo=timezone.utc).timestamp() * 1000)) if a.start else ts[0]
    hi = min(ts[-1], int(datetime.fromisoformat(a.end).replace(tzinfo=timezone.utc).timestamp() * 1000)) if a.end else ts[-1]
    lo, hi = lo // DAY * DAY, (hi // DAY + 1) * DAY
    n = (hi - lo) // MIN
    print(f"prices: {len(pr)} minute bars; testing {n} minutes", file=sys.stderr)
    A = T.build_astro(lo, hi, a.cache)
    A3 = build_astro3(lo, hi, a.cache3)
    o, h, l, c, ok = B.align_prices(pr, lo, n)
    can, flat = B.make_windows(lo, n, p)
    X = type("X", (), {})()
    X.o, X.h, X.l, X.c, X.ok, X.can, X.flat, X.p = o, h, l, c, ok, can, flat, p
    X.emaL, X.emaH = ema_carry(l, ok, a.ema), ema_carry(h, ok, a.ema)
    Mk = M(A, A3)
    t0 = time.time()

    print(f"Levels: 1 Sun field falling + Mercury card falling; 2 Moon >= 2 hard aspects to transit/natal Mars, Sun, Jupiter; "
          f"3 Pluto/Saturn Ascendant aspect {ALLOWED}, actors amber with Moon lit, natal point on the Midheaven (--res {a.res}); "
          f"4 1-minute close below the {a.ema} EMA of lows, SL {a.sl:g}, breakeven at +{a.be:g}, trail the {a.ema} EMA of highs.")

    # ---- funnel: how rare is each level
    act, el, el3, g = Mk.build(True, True, a.res)
    tot = n
    cnt = lambda m: bin(m).count("1")
    ones = Mk.ones
    print("\n=== 1. HOW OFTEN EACH LEVEL IS ON (share of all minutes, 2024-today) ===")
    lvl1 = Mk.fall & Mk.mfall
    print(f"  Sun field falling               {100*cnt(Mk.fall)/tot:5.1f}%")
    print(f"  Mercury card falling            {100*cnt(Mk.mfall)/tot:5.1f}%")
    print(f"  Level 1 (both)                  {100*cnt(lvl1)/tot:5.1f}%")
    print(f"  Level 2 (Moon 2+ hard aspects)  {100*cnt(Mk.moon2)/tot:5.1f}%")
    print(f"  Levels 1 + 2                    {100*cnt(lvl1 & Mk.moon2)/tot:5.1f}%")
    print(f"  Level 3 without resonance       {100*cnt(Mk.build(True, True, 'off')[2])/tot:5.1f}%")
    print(f"  Level 3 with resonance          {100*cnt(el3)/tot:5.2f}%")
    runs5 = len([1 for m_ in re.finditer(rb"\x01+", el) if m_.end() - m_.start() >= a.min_run])
    print(f"  Levels 1 + 2 + 3 together       {100*cnt(int.from_bytes(el, 'big'))/tot:5.2f}%   ({runs5} runs of 5+ minutes)")

    rows, res = [], {}

    def go(label, **kw):
        tf = kw.pop("trail_from", "be")
        ea = kw.pop("exit_aspect", False)
        act_b, el_b, _, _ = Mk.build(**kw)
        tr = run(act_b, el_b, X, tf, ea, a.per_window)
        s = describe(tr, lo, p)
        rows.append((label, s["n"], round(s["win"], 1), round(s["mean"], 1), round(s["t"], 2)))
        res[label] = (s, tr)
        return s, tr

    variants = [
        ("THE LADDER AS SPECIFIED", dict(res=a.res)),
        ("trail the EMA of highs from entry (not only after breakeven)", dict(res=a.res, trail_from="entry")),
        ("also exit when the Level 3 aspect ends", dict(res=a.res, exit_aspect=True)),
        ("resonance: natal Pluto OR natal Saturn on the Midheaven", dict(res="either")),
        ("without the Midheaven resonance", dict(res="off")),
        ("without Level 1", dict(l1=False, res=a.res)),
        ("without Level 2", dict(l2=False, res=a.res)),
        ("Pluto trigger only", dict(res=a.res, kinds=("pluto",))),
        ("Saturn trigger only", dict(res=a.res, kinds=("saturn",))),
    ]
    print("\n=== 2. RESULTS (points per trade after the 21-point spread; t = gross edge before the spread) ===")
    print(f"{'variant':62s}    n    mean   (t)   win%  avg win  avg loss  hold(min)  2024-25   2026   exits SL/BE/TRAIL/FLAT/ASP")
    for label, kw in variants:
        s, _ = go(label, **kw)
        ins = "   -  " if s["m_ins"] is None else f"{s['m_ins']:+6.1f}"
        out = "   -  " if s["m_out"] is None else f"{s['m_out']:+6.1f}"
        mx = s["mix"]
        print(f"{label:62s} {T.fmt(s)} {s['win']:5.1f}  {s['avg_win']:+7.1f}  {s['avg_loss']:+8.1f}  {s['hold']:7.0f}    {ins} {out}    "
              f"{mx['SL']}/{mx['BE']}/{mx['TRAIL']}/{mx['FLAT']}/{mx['ASPECT']}")

    m = len(rows)
    from statistics import NormalDist
    z = NormalDist().inv_cdf(1 - 0.025 / max(1, m))
    print(f"\n=== 3. HOW MUCH TO TRUST ANY SINGLE ROW ===")
    print(f"{m} variants were tested. A row only counts as a real edge if its gross t is above {z:.1f}, AND its net mean is above zero, "
          f"AND it is positive in both 2024-25 and 2026, AND n >= 100. (With few trades the t is weak: n is shown next to every row.)")
    good = [lab for lab, (s, _) in res.items() if s["n"] >= 100 and s["t"] >= z and s["mean"] > 0 and (s["m_ins"] or 0) > 0 and (s["m_out"] or 0) > 0]
    print("rows that pass:", "none" if not good else ", ".join(good))
    small = [lab for lab, (s, _) in res.items() if s["n"] < 100]
    if small:
        print("rows with fewer than 100 trades (too few to judge):", ", ".join(small))

    if a.null > 0:
        print("\n=== 4. RANDOM-TIMING TEST for the specified ladder: all astro flags shifted by whole weeks ===")
        shifts = [s for w in range(1, a.null // 2 + 2) for s in (w, -w)][:a.null]
        real = res["THE LADDER AS SPECIFIED"][0]["mean"]
        nulls, ns = [], []
        for w in shifts:
            A2, B2 = shifted(A, A3, w * 7 * 1440)
            act_b, el_b, _, _ = M(A2, B2).build(res=a.res)
            tr = run(act_b, el_b, X, "be", False, a.per_window)
            if tr:
                nulls.append(statistics.mean(x[3] for x in tr) / p["point"])
                ns.append(len(tr))
        if nulls:
            print(f"real {real:+6.1f}; shifted runs mean {statistics.mean(nulls):+6.1f}, best {max(nulls):+6.1f}, worst {min(nulls):+6.1f}, "
                  f"typical trade count {statistics.median(ns):.0f}; real beats {100*sum(1 for x in nulls if x < real)/len(nulls):.0f}% of them")

    with open(a.out, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["variant", "entry_utc", "exit_utc", "reason", "points"])
        tu = lambda i: datetime.fromtimestamp((lo + i * MIN) / 1000, tz=timezone.utc).strftime("%Y-%m-%d %H:%M")
        for label, (s, tr) in res.items():
            for k, jx, reason, pnl in tr:
                w.writerow([label, tu(k), tu(jx), reason, round(pnl / p["point"], 1)])
    print(f"\ntrades of every variant written to {a.out}   (took {time.time()-t0:.0f}s)")


if __name__ == "__main__":
    main()
