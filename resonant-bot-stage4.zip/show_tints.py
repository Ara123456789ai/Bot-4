#!/usr/bin/env python3
"""Prints when the Sun-pane tint and the Mercury-pane tint flip on one UTC day, so you can compare with the app.
Usage: python3 show_tints.py 2026-11-10"""
import os, sys, datetime as dt
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import resonant_engine as E

day = dt.datetime.strptime(sys.argv[1], "%Y-%m-%d").replace(tzinfo=dt.timezone.utc)
t0 = int(day.timestamp() * 1000)
prev = {}
print(f"tint flips on {sys.argv[1]} (UTC; the app shows your phone's local time)")
for i in range(288):
    ms = t0 + i * E.BAR_MS
    now = {"Sun-only pane": E.helio_trend(ms) < 0, "Mercury-only pane": E.merc_trend(ms) < 0}
    for k, v in now.items():
        if k in prev and prev[k] != v or (k not in prev and i == 0):
            print(f"  {i*5//60:02d}:{i*5%60:02d}  {k}: {'RED (falling)' if v else 'GREEN (rising)'}")
    prev = now
